<?php

namespace Reactor\WebService;

use \Reator\Events\Event;

class SlimController {

    protected $application;

    public function __construct($application) {
        $this->application = $application;
    }

    public function handle($request_responce) {
        
    }

}
