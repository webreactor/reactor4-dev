<?php

namespace Reactor\WebService;

class Response {

}
