<?php

namespace Reactor\WebService;

interface RouterInterface {
    public function route($request_responce);
}
